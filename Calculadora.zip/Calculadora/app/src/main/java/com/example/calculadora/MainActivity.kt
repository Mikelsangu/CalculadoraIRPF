package com.example.calculadora

import android.R
import android.R.attr.color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialogDefaults.containerColor
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DividerDefaults.color
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDefaults.color
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.calculadora.ui.theme.CalculadoraTheme
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            CalculadoraTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    CalculadoraApp(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun CalculadoraApp(modifier: Modifier = Modifier) {
    var mostrarResultados by remember { mutableStateOf(false) }

    var edad by remember { mutableStateOf("") }
    var grupoProfesional by remember { mutableStateOf("") }
    var discapacidad by remember { mutableStateOf("Ninguna") }
    var estadoCivil by remember { mutableStateOf("") }
    var numeroHijos by remember { mutableStateOf("") }
    var salarioBruto by remember { mutableStateOf("") }
    var numeroPagas by remember { mutableStateOf("") }

    var mensajeError by remember { mutableStateOf("") }

    var brutoAnualCalculado by remember { mutableStateOf(0.0) }
    var irpfCalculado by remember { mutableStateOf(0.0) }
    var seguridadSocialCalculada by remember { mutableStateOf(0.0) }
    var netoAnualCalculado by remember { mutableStateOf(0.0) }
    var pagasCalculadas by remember { mutableStateOf(12) }

    if (mostrarResultados) {
        PantallaResultados(
            brutoAnual = brutoAnualCalculado,
            netoAnual = netoAnualCalculado,
            irpf = irpfCalculado,
            seguridadSocial = seguridadSocialCalculada,
            numeroPagas = pagasCalculadas,
            alVolver = { mostrarResultados = false },
            modifier = modifier
        )
    } else {
        PantallaFormulario(
            edad = edad,
            alCambiarEdad = { edad = it },
            grupoProfesional = grupoProfesional,
            alCambiarGrupo = { grupoProfesional = it },
            discapacidad = discapacidad,
            alCambiarDiscapacidad = { discapacidad = it },
            estadoCivil = estadoCivil,
            alCambiarEstadoCivil = { estadoCivil = it },
            numeroHijos = numeroHijos,
            alCambiarHijos = { numeroHijos = it },
            salarioBruto = salarioBruto,
            alCambiarSalario = { salarioBruto = it },
            numeroPagas = numeroPagas,
            alCambiarPagas = { numeroPagas = it },
            mensajeError = mensajeError,
            alCalcular = {
                val edadNumero = edad.toIntOrNull()
                val hijosNumero = numeroHijos.toIntOrNull()
                val bruto = salarioBruto.replace(",", ".").toDoubleOrNull()
                val pagas = numeroPagas.toIntOrNull()

                when {
                    edadNumero == null || edadNumero <= 0 ->
                        mensajeError = "Introduce una edad válida."
                    grupoProfesional.isBlank() ->
                        mensajeError = "Selecciona un grupo profesional."
                    estadoCivil.isBlank() ->
                        mensajeError = "Selecciona tu estado civil."
                    hijosNumero == null || hijosNumero < 0 ->
                        mensajeError = "Introduce un número de hijos válido."
                    bruto == null || bruto <= 0 ->
                        mensajeError = "Introduce un salario bruto anual válido."
                    pagas == null || pagas !in 12..15 ->
                        mensajeError = "El número de pagas debe estar entre 12 y 15."
                    else -> {
                        val irpf = calcularIrpf(
                            salarioBruto = bruto,
                            hijos = hijosNumero,
                            discapacidad = discapacidad,
                            estadoCivil = estadoCivil,
                            edad = edadNumero
                        )

                        val seguridadSocial = bruto * 0.0635

                        brutoAnualCalculado = bruto
                        irpfCalculado = irpf
                        seguridadSocialCalculada = seguridadSocial
                        netoAnualCalculado = bruto - irpf - seguridadSocial
                        pagasCalculadas = pagas
                        mensajeError = ""
                        mostrarResultados = true
                    }
                }
            },
            modifier = modifier
        )
    }
}

@Composable
fun PantallaFormulario(
    edad: String,
    alCambiarEdad: (String) -> Unit,
    grupoProfesional: String,
    alCambiarGrupo: (String) -> Unit,
    discapacidad: String,
    alCambiarDiscapacidad: (String) -> Unit,
    estadoCivil: String,
    alCambiarEstadoCivil: (String) -> Unit,
    numeroHijos: String,
    alCambiarHijos: (String) -> Unit,
    salarioBruto: String,
    alCambiarSalario: (String) -> Unit,
    numeroPagas: String,
    alCambiarPagas: (String) -> Unit,
    mensajeError: String,
    alCalcular: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFFFB74D))
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Simulador de nómina",
            style = MaterialTheme.typography.headlineMedium,
            color = Color(0xFF1A1A1A)
        )
        Text("Introduce tus datos para estimar el salario neto y las retenciones.")

        OutlinedTextField(
            value = edad,
            onValueChange = alCambiarEdad,
            label = { Text("Edad") },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Selector(
            etiqueta = "Grupo profesional",
            opciones = listOf(
                "Grupo A",
                "Grupo B",
                "Grupo C",
                "Grupo D",
                "Grupo E"
            ),
            seleccionado = grupoProfesional,
            alSeleccionar = alCambiarGrupo
        )

        Selector(
            etiqueta = "Grado de discapacidad",
            opciones = listOf("Ninguna", "Menos del 33%", "Del 33% al 64%", "65% o más"),
            seleccionado = discapacidad,
            alSeleccionar = alCambiarDiscapacidad
        )

        Selector(
            etiqueta = "Estado civil",
            opciones = listOf("Soltero/a", "Casado/a", "Otro"),
            seleccionado = estadoCivil,
            alSeleccionar = alCambiarEstadoCivil
        )

        OutlinedTextField(
            value = numeroHijos,
            onValueChange = alCambiarHijos,
            label = { Text("Número de hijos") },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = salarioBruto,
            onValueChange = alCambiarSalario,
            label = { Text("Salario bruto anual (€)") },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = numeroPagas,
            onValueChange = alCambiarPagas,
            label = { Text("Número de pagas (12–15)") },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White
            ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (mensajeError.isNotEmpty()) {
            Text(
                text = mensajeError,
                color = MaterialTheme.colorScheme.error
            )
        }

        Button(
            onClick = alCalcular,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF1565C0)
            )
        ) {
            Text("Calcular nómina")
        }

        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
fun Selector(
    etiqueta: String,
    opciones: List<String>,
    seleccionado: String,
    alSeleccionar: (String) -> Unit
) {
    var desplegado by remember { mutableStateOf(false) }

    Column {
        Text(text = etiqueta, style = MaterialTheme.typography.labelLarge)

        TextButton(onClick = { desplegado = true }) {
            Text(if (seleccionado.isBlank()) "Seleccionar" else seleccionado)
        }

        DropdownMenu(
            expanded = desplegado,
            onDismissRequest = { desplegado = false },
            containerColor = Color.White
        ) {
            opciones.forEach { opcion ->
                DropdownMenuItem(
                    text = { Text(opcion) },
                    onClick = {
                        alSeleccionar(opcion)
                        desplegado = false
                    }
                )
            }
        }
    }
}

@Composable
fun PantallaResultados(
    brutoAnual: Double,
    netoAnual: Double,
    irpf: Double,
    seguridadSocial: Double,
    numeroPagas: Int,
    alVolver: () -> Unit,
    modifier: Modifier = Modifier
) {
    val netoPorPaga = netoAnual / numeroPagas

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Resultado de la simulación",
            style = MaterialTheme.typography.headlineMedium
        )

        ResultadoFila("Salario bruto anual", brutoAnual)
        ResultadoFila("Retención de IRPF", irpf)
        ResultadoFila("Deducción de Seguridad Social", seguridadSocial)
        ResultadoFila("Salario neto anual", netoAnual)
        ResultadoFila("Salario neto por paga ($numeroPagas pagas)", netoPorPaga)

        Text(
            text = "Importes estimados con fines educativos. No son un cálculo oficial de nómina.",
            style = MaterialTheme.typography.bodySmall
        )

        Button(
            onClick = alVolver,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF1565C0)
            )
        ) {
            Text("Volver al formulario")
        }
    }
}

@Composable
fun ResultadoFila(etiqueta: String, importe: Double) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(etiqueta, modifier = Modifier.weight(1f))
        Text(formatearEuros(importe))
    }
}

fun calcularIrpf(
    salarioBruto: Double,
    hijos: Int,
    discapacidad: String,
    estadoCivil: String,
    edad: Int
): Double {
    // Tramos progresivos publicados en la tabla del artículo.
    val limites = listOf(12_450.0, 20_200.0, 35_200.0, 60_000.0, 300_000.0)
    val tipos = listOf(0.19, 0.24, 0.30, 0.37, 0.45, 0.47)

    var impuesto = 0.0
    var limiteAnterior = 0.0

    for (indice in tipos.indices) {
        val limiteSuperior =
            if (indice < limites.size) limites[indice] else Double.POSITIVE_INFINITY

        val importeEnTramo =
            (salarioBruto.coerceAtMost(limiteSuperior) - limiteAnterior).coerceAtLeast(0.0)

        impuesto += importeEnTramo * tipos[indice]

        if (salarioBruto <= limiteSuperior) break
        limiteAnterior = limiteSuperior
    }

    // Ajustes didácticos: el artículo indica que estas circunstancias
    // pueden reducir la retención; no son el cálculo oficial de Hacienda.
    var reduccion = hijos * 0.01

    reduccion += when (discapacidad) {
        "Menos del 33%" -> 0.0
        "Del 33% al 64%" -> 0.02
        "65% o más" -> 0.04
        else -> 0.0
    }

    if (estadoCivil == "Casado/a") reduccion += 0.01
    if (edad >= 65) reduccion += 0.01

    return (impuesto * (1.0 - reduccion.coerceIn(0.0, 0.30)))
        .coerceIn(0.0, salarioBruto)
}


fun formatearEuros(importe: Double): String {
    return String.format(Locale("es", "ES"), "%.2f €", importe)
}